# Diesel Life V7

This is a browser-game starter build with:

- Dark industrial garage home screen
- Garage / Race / Pull / Show / Map navigation
- Customization categories
- Installable parts
- Money system saved in localStorage
- Power, torque, grip, weight and style stats
- Visual wheel/lift/paint/underglow previews
- Playable 1/4-mile drag race
- Touch throttle / shift / nitrous controls
- Keyboard controls
- AI opponent
- Win/loss payout

## IMPORTANT

Put your existing truck PNG here:

assets/truck.png

If that file is missing, the garage truck will not show.

## Upload to GitHub

Replace your current project files with:

index.html
style.css
game.js

and create:

assets/truck.png

Then commit the changes. If GitHub Pages is already enabled on the repository, refresh the game page after the commit finishes.

## Next planned build

V7.1:
- Real separate wheel PNG overlays lined up exactly to the truck
- Tire overlays
- Bumpers, headlights, stacks, mirrors
- Better drag-race graphics
- transmission tuning
- build save slots
- dealership / truck selection
